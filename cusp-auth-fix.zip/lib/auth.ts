import { cookies } from "next/headers"

// User interface
export interface User {
  id: string
  username: string
  password: string
  role: "teacher" | "student"
  fullName?: string
  email?: string
  createdBy?: string
  createdAt: Date
}

// Mock teacher accounts
const teachers: User[] = [
  {
    id: "1",
    username: "s.s parmar",
    password: "s.s parmar",
    role: "teacher",
    fullName: "S.S. Parmar",
    createdAt: new Date(),
  },
  {
    id: "2",
    username: "n.v limbad",
    password: "n.v limbad",
    role: "teacher",
    fullName: "N.V. Limbad",
    createdAt: new Date(),
  },
  {
    id: "3",
    username: "s.g bhalgama",
    password: "s.g bhalgama",
    role: "teacher",
    fullName: "S.G. Bhalgama",
    createdAt: new Date(),
  },
]

// Mock student accounts
const students: User[] = [
  {
    id: "4",
    username: "student",
    password: "student",
    role: "student",
    fullName: "Sample Student",
    createdBy: "1",
    createdAt: new Date(),
  },
]

// Authentication function
export async function authenticate(username: string, password: string): Promise<User | null> {
  // Check teachers
  const teacher = teachers.find((t) => t.username.toLowerCase() === username.toLowerCase() && t.password === password)

  if (teacher) {
    return teacher
  }

  // Check students
  const student = students.find((s) => s.username.toLowerCase() === username.toLowerCase() && s.password === password)

  if (student) {
    return student
  }

  return null
}

// Get current user from cookies
export function getCurrentUser(): User | null {
  const cookieStore = cookies()
  const userCookie = cookieStore.get("currentUser")

  if (!userCookie) {
    return null
  }

  try {
    return JSON.parse(userCookie.value) as User
  } catch (error) {
    return null
  }
}
