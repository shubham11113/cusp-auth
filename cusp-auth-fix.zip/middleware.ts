import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Get the pathname of the request
  const path = request.nextUrl.pathname

  // Define public paths that don't require authentication
  const isPublicPath = path === "/" || path === "/login"

  // Get the token from cookies
  const isAuthenticated = request.cookies.has("currentUser")

  // Redirect logic
  if (isPublicPath && isAuthenticated) {
    // If user is authenticated and trying to access public path,
    // redirect to dashboard based on role
    const userCookie = request.cookies.get("currentUser")?.value
    if (userCookie) {
      try {
        const user = JSON.parse(userCookie)
        if (user.role === "teacher") {
          return NextResponse.redirect(new URL("/teacher/dashboard", request.url))
        } else {
          return NextResponse.redirect(new URL("/student/dashboard", request.url))
        }
      } catch (error) {
        // If parsing fails, continue
      }
    }
  }

  if (!isPublicPath && !isAuthenticated) {
    // If user is not authenticated and trying to access protected path,
    // redirect to login
    return NextResponse.redirect(new URL("/login", request.url))
  }

  return NextResponse.next()
}

// Configure the paths that should be processed by this middleware
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!api|_next/static|_next/image|favicon.ico).*)",
  ],
}
