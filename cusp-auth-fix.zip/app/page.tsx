"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { useEffect } from "react"

export default function HomePage() {
  const router = useRouter()

  // Check if user is already logged in
  useEffect(() => {
    const currentUser = localStorage.getItem("currentUser")
    if (currentUser) {
      const user = JSON.parse(currentUser)
      if (user.role === "teacher") {
        router.push("/teacher/dashboard")
      } else {
        router.push("/student/dashboard")
      }
    }
  }, [router])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-blue-500 to-purple-600 p-4">
      <div className="text-center text-white mb-16">
        <h1 className="text-5xl font-bold mb-4 text-shadow">CUSP Examination System</h1>
        <p className="text-xl opacity-90">Online examination platform for students and teachers</p>
      </div>

      <div className="flex flex-col md:flex-row gap-8 w-full max-w-4xl">
        <div className="bg-white rounded-xl p-8 text-center flex-1 shadow-xl transform transition-transform hover:-translate-y-2">
          <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-10 w-10 text-blue-500"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
              />
            </svg>
          </div>
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Student Login</h2>
          <p className="text-gray-600 mb-6">Take exams and view your results</p>
          <Button
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
            onClick={() => router.push("/login?role=student")}
          >
            Login as Student
          </Button>
        </div>

        <div className="bg-white rounded-xl p-8 text-center flex-1 shadow-xl transform transition-transform hover:-translate-y-2">
          <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-10 w-10 text-purple-500"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
              />
            </svg>
          </div>
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Teacher Login</h2>
          <p className="text-gray-600 mb-6">Create exams and manage students</p>
          <Button
            className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
            onClick={() => router.push("/login?role=teacher")}
          >
            Login as Teacher
          </Button>
        </div>
      </div>

      <footer className="mt-16 text-white/80 text-sm">
        &copy; {new Date().getFullYear()} CUSP Examination System. All rights reserved.
      </footer>
    </div>
  )
}
