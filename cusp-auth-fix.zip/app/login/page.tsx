"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export default function LoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault()
    setLoading(true)
    setError("")

    try {
      const response = await login(username, password)

      if (response) {
        // Redirect based on user role
        if (response.role === "teacher") {
          router.push("/teacher/dashboard")
        } else {
          router.push("/student/dashboard")
        }
      } else {
        setError("Invalid username or password")
      }
    } catch (err) {
      setError("An error occurred during login. Please try again.")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  // Mock authentication function that mimics the behavior in auth.service.ts
  async function login(username: string, password: string) {
    // Mock teacher accounts from the original auth.service.ts
    const teachers = [
      {
        id: "1",
        username: "s.s parmar",
        password: "s.s parmar",
        role: "teacher",
        fullName: "S.S. Parmar",
        createdAt: new Date(),
      },
      {
        id: "2",
        username: "n.v limbad",
        password: "n.v limbad",
        role: "teacher",
        fullName: "N.V. Limbad",
        createdAt: new Date(),
      },
      {
        id: "3",
        username: "s.g bhalgama",
        password: "s.g bhalgama",
        role: "teacher",
        fullName: "S.G. Bhalgama",
        createdAt: new Date(),
      },
    ]

    // Mock student account
    const students = [
      {
        id: "4",
        username: "student",
        password: "student",
        role: "student",
        fullName: "Sample Student",
        createdBy: "1",
        createdAt: new Date(),
      },
    ]

    // Check teachers
    const teacher = teachers.find((t) => t.username.toLowerCase() === username.toLowerCase() && t.password === password)

    if (teacher) {
      // Store user in localStorage to persist session
      localStorage.setItem("currentUser", JSON.stringify(teacher))
      return teacher
    }

    // Check students
    const student = students.find((s) => s.username.toLowerCase() === username.toLowerCase() && s.password === password)

    if (student) {
      // Store user in localStorage to persist session
      localStorage.setItem("currentUser", JSON.stringify(student))
      return student
    }

    return null
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-r from-blue-500 to-purple-600 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center bg-gradient-to-r from-blue-500 to-purple-600 text-white">
          <CardTitle className="text-2xl font-bold">CUSP Examination System</CardTitle>
          <CardDescription className="text-white/80">Login to access your account</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                placeholder="Enter your username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Logging in..." : "Login"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
